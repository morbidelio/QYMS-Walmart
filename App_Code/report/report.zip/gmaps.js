﻿var map;
var markers = [];
function trim(myString) {
    return myString.replace(/^\s+/g, '').replace(/\s+$/g, '')
}
function cargamapa(zoom1, mapObj, lat, lon) {

    var center = (lat == undefined || lon == undefined) ? new google.maps.LatLng(-33.45238466, -70.65735526) : new google.maps.LatLng(lat,lon);
    this.map = new google.maps.Map(mapObj, {
        center: center,
        zoom: zoom1
    });
}
function marcaTrailer(id, name, lat, lon, fec, dir, vel, transportista) {
    var icono;
    if (dir > 338 || dir <= 22)
        icono = "../images/ico/camnegro_N.png";

    else if (dir > 22 && dir <= 67)
        icono = "../images/ico/camnegro_NE.png";

    else if (dir > 67 && dir <= 112)
        icono = "../images/ico/camnegro_E.png";

    else if (dir > 112 && dir <= 157)
        icono = "../images/ico/camnegro_SE.png";

    else if (dir > 157 && dir <= 202)
        icono = "../images/ico/camnegro_S.png";

    else if (dir > 202 && dir <= 257)
        icono = "../images/ico/camnegro_SO.png";

    else if (dir > 257 && dir <= 292)
        icono = "../images/ico/camnegro_O.png";

    else if (dir > 292 && dir <= 338)
        icono = "../images/ico/camnegro_NO.png";

    else
        icono = "../images/ico/camnegro_N.gif";

    marker(id, name, icono, new google.maps.LatLng(lat, lon));
}

function marker(id, marca, icono, location) {
    if (markers[id]) {
        markers[id].setPosition(location);
        markers[id].setIcon(icono);
    }
    else {
        markers[id] = new google.maps.Marker({
            map: map
            , position: location
            , title: marca
            , icon: icono
            , visible: true
        });
    }

    var mov1 = trim(marca);
    var mov2 = trim(marca);

    if (mov2 == mov1) {
        map.setCenter(location);
    }
}